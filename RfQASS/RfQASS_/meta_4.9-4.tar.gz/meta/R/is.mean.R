is.mean <- function(x)
  x %in% .settings$sm4mean
