is.cor <- function(x)
  x %in% .settings$sm4cor
