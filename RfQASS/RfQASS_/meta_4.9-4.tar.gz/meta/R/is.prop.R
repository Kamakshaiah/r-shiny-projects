is.prop <- function(x)
  x %in% .settings$sm4prop
