trimfill <- function (x, ...) 
  UseMethod("trimfill")
