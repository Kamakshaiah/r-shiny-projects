radial <- function (x, ...) 
  UseMethod("radial")
