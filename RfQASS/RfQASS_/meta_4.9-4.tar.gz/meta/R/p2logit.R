p2logit <- function(x) {
  res <- log(x) / log(1 - x)
  res
}
