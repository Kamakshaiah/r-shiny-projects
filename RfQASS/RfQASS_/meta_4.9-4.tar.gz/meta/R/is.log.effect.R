is.log.effect <- function(x)
  x %in% c("PLN", "IRLN", "MLN")
