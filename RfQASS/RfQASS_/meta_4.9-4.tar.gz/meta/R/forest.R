forest <- function (x, ...) 
  UseMethod("forest")
