is.untransformed <- function(x)
  x %in% c("COR", "PRAW", "IR", "RD", "IRD", "MD", "SMD", "MRAW")
