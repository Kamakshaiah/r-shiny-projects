z2cor <- function(x) {
  res <- (exp(2 * x) - 1) / (exp(2 * x) + 1)
  res
}
