funnel <- function (x, ...) 
  UseMethod("funnel")
